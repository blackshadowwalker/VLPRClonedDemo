//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by VLPRClonedDemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_VLPRCLONEDDEMO_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_LOADING              129
#define BT_ADD_BROWSER                  1000
#define BT_DIRS_CLEAR                   1001
#define IDC_LIST_DIRS                   1004
#define BT_ANAY                         1005
#define ID_PROCESS_STATUS               1006
#define ID_VIDEO_WALL                   1007
#define ID_STATUS                       1008
#define ID_LPR_PICTURE                  1009
#define IDC_LIST                        1010
#define ID_PICTURE                      1011
#define IDC_EDIT_THREAD                 1012
#define BT_BROWSER_DEST_DIR             1013
#define IDC_EDIT_DST_DIR                1014
#define BT_RE_LOAD                      1015
#define ID_STATUS_LIST                  1016
#define BT_RESULT_STATUS                1017
#define ID_PLAY_STATUS                  1018
#define ID_MSG                          1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
